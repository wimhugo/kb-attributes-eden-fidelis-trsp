# TRSP specification candidate — 10 November 2026

- Created candidate DOCX with conceptual model, term inventories, property tables, SHACL inventory and examples.
- Preserved supplied `trsp-core.ttl`; generated separate parsing-only working copy.
- Added core-alignment review sections to five Markdown guidance files.
- Recorded schema inconsistencies for human review rather than applying semantic changes.
- The OpenREL document is used as a presentation/section-structure reference, not as a normative TRSP source.
