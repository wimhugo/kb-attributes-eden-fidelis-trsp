# TRSP attribute hierarchy — preliminary quality audit

Input: `attributes-type.ttl` (9,766 lines). This is a *non-destructive* review; no source concepts were changed.

## Structural inventory

- 651 `trsp:att.*` subject declarations, 651 distinct IRIs (no repeated attribute subject identifiers in this file).
- All 651 attribute blocks contain `skos:prefLabel`, `skos:definition`, `skos:inScheme` and `trsp:property` (textual block check; not yet RDF semantic validation).
- 8 blocks do not contain `skos:broader`; these may be intended top-level concepts.
- Full Turtle parse fails; therefore counts are based on source-level inspection rather than a validated RDF graph.

## Priority syntax issues

- 49 occurrences of bare typed-literal suffixes such as `trsp:algorithmClass ^^xsd:string` (invalid Turtle; inspect intended datatype or missing value).
- 25 occurrences of `trspService` (not a prefixed IRI or literal; verify whether `trsp:Service` is intended).
- 3 unquoted `{Vocabulary: ...}` placeholders (not Turtle RDF terms).
- 1 `NOT` expression in a comma-separated object list; encode formally, rather than as Turtle syntax.
- Turtle parser first stops at line 526.

## Additional modelling and editorial checks

1. Validate each `skos:broader` target, cycles, disconnected hierarchy branches, and root count after syntax repair.
2. Compare labels and definitions for duplicates and near-duplicates, and detect inconsistent `trsp:property` strings.
3. Validate `trsp:algorithmClass`, `trsp:algorithmConstraint`, `trsp:hasBenchmark`, and measurement/cardinality types against the current core ontology and shapes.
4. Inspect datatype placeholders, benchmark capitalization (`classConstraint` versus `ClassConstraint`), and references to external vocabularies.
5. Review duplicated `dct:modified` values on the concept scheme and language tags on labels.
6. Review namespace IRIs and unused prefix declarations; do not assume that every syntactically valid IRI dereferences.

## Recommendation

Perform a separate, conservative syntax-repair pass before modifying the attribute hierarchy or its semantics. Do not silently replace missing values or free-text placeholders with guessed resources. Once the RDF graph parses, perform full hierarchy, duplicate, reference, and SHACL checks.
