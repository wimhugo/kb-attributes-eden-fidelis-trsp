# TRSP core ontology revision 2 — Property class

Source: `trsp-core-reviewed(1).ttl`; example: `item-61.ttl`.

## Changes

- Added `trsp:Property` as `owl:Class`, `rdfs:subClassOf rdf:Property`, with label, definition and modelling note.
- Added `trsp:linkedProperty` (domain `trsp:Property`, range `rdf:Property`).
- Extended `trsp:hasAttribute` domain to an OWL union of `trsp:Property` and `trsp:ProfileProperty`.
- Extended `trsp:hasProperty` range to an OWL union of `trsp:Property` and `trsp:ProfileProperty`.
- Extended `trsp:hasProfile` domain to an OWL union of `trsp:Property`, `trsp:ProfileProperty`, `trsp:Repository`, and `trsp:Service`. This domain is provisional: the property is broadly described as relating a resource to a profile.
- Extended domains of `trsp:hasCardinalityType`, `trsp:hasMeasurementType`, and `trsp:hasBenchmark` to OWL unions of `trsp:Attribute`, `trsp:Property`, and `trsp:ProfileProperty`.
- Updated ontology modification date.

## Design decisions / cautions

1. `trsp:Property rdfs:subClassOf rdf:Property` entails every `trsp:Property` individual is an RDF predicate. If these individuals are specifications rather than actual predicates, a class without this subclass relation is preferable. `rdf:Property` is an RDFS class rather than a conventional OWL class; assess OWL DL tooling compatibility.
2. `trsp:Property` and `trsp:ProfileProperty` currently overlap. Retained both to avoid breaking existing references. Decide whether `trsp:ProfileProperty` is an association/reification class or a redundant synonym.
3. The FIDELIS sample uses `skos:exactMatch`/`skos:closeMatch` to relate property specifications to attributes; `trsp:hasAttribute` can be used to make this relationship explicit, but the sample has not been modified.
4. `trsp:hasProfileType` in the example points to a literal (`"trsp:profile-type-community"`), whereas the ontology expects an IRI in its object range; its existing range also appears inconsistent with the name. Requires a separate correction.
5. `trsp:hasBenchmark` ranges over `skos:Concept`; example benchmark targets may not all be typed as concepts. Confirm with the benchmark vocabulary.
6. The sample `item-61.ttl` does not parse as Turtle in its current form: `rdf:label` is used instead of `rdfs:label` and the bare token `fidelis.listMetadata` is not a valid prefixed name or IRI. The example also uses a different `trsp:` namespace from the core ontology. These sample issues were not changed in the ontology output.
7. RDFS/OWL domain and range declarations are inferential, not closed-world validation constraints. Update SHACL shapes to enforce profile-property constraints once the class distinction is settled.

## Validation

The revised core file parses successfully with RDFLib as Turtle: **493 triples**. This is syntax validation, not a complete OWL consistency or SHACL data-validation result.
