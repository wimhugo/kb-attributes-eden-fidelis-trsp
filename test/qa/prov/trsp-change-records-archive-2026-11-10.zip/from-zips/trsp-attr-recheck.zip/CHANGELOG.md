# TRSP attribute batch — recheck against newly uploaded originals

Inputs: `attr(1).zip` and `trsp-core(2).ttl`. All 39 output vocabulary files and the revised core parse as Turtle using RDFLib 7.5.0. Original directory paths preserved. No prior reviewed ZIP was used as input.

## Applied corrections

### `community-check.ttl`

- Added missing care: prefix

### `compensation-rule-type.ttl`

- Added missing dct: prefix
- Corrected XML Schema datatype capitalization
- Added missing prov: prefix
- Corrected blank node terminator
- Added missing foaf: prefix

### `curation-check.ttl`

- Added missing ttrsp: prefix
- Corrected ttrsp: typo to trsp:
- Added missing statement terminator

### `institution-role-type.ttl`

- Added missing r3d: prefix
- Replaced invalid prefixed local path with dot-separated identifier

### `legislation-type.ttl`

- Removed premature statement terminator inside blank node

### `linkages-type.ttl`

- Added missing owl: prefix

### `metrics-check.ttl`

- Wrapped custom-scheme IRI in angle brackets; URI scheme requires verification
- Wrapped remaining eden:// IRIs

### `principles-check.ttl`

- Added missing predicate separator

### `registry-check.ttl`

- Added missing dcat: prefix
- Added missing schema: prefix

### `revenue-type.ttl`

- Added missing dct: prefix
- Corrected XML Schema datatype capitalization
- Added missing prov: prefix
- Added missing foaf: prefix
- Corrected blank node terminator

### `trl-type.ttl`

- Moved trsp:levelNumber datatype property declaration to core ontology

### `trsp-core.ttl`

- Removed invalid comma after trsp:correspondingClass
- Relocated trsp:levelNumber from trl-type.ttl; added domain and SKOS definition (domain provisional)

## Corpus-level checks

- Vocabulary files: 39
- Missing SKOS metadata entries: 235 ({'definition': 235})
- IRIs defined as subjects in multiple vocabulary files: 1
- Explicit schema declarations remaining in vocabulary files: 3
- Unused prefix declarations: 35

## Open issues / editorial review

- Missing SKOS definitions are inventoried, not invented from labels. See `MISSING-METADATA.tsv`.
- `resource-type.ttl` declares three properties in the `https://example.org/rdmi-resource-type/` namespace, but data statements use the separate `rtp:` property namespace. These declarations do not define the predicates actually used. Their intended canonical IRIs must be confirmed before relocation into the TRSP core. See `EMBEDDED-SCHEMA.tsv`.
- `trsp:levelNumber` has been relocated to core. Its added `trsp:ProfileProperty` domain is provisional: it may instead describe a SKOS concept for a TRL level; verify intended usage.
- `eden://validator/metric/endpointAvailability` is syntactically an absolute IRI but not an HTTP URL; confirm whether it should be replaced with a canonical resolvable HTTPS IRI.
- The `care:` and `r3d:` namespace bindings added to repair parsing require verification against the intended external vocabularies.
- Check `IRI-OVERLAPS.tsv` for shared subject identifiers and their metadata.
- RDF parsing is not SHACL validation, dereferenceability testing or proof of semantic consistency.
