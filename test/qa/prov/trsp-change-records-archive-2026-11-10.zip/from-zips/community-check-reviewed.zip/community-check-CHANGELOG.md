# Community Engagement Checklist — Revision 0.2

## Added
- Two top-level SKOS concepts: `trsp:typeInclusivity` and `trsp:typeUserNeeds`.
- Five narrower concepts for each category, with English preferred labels, definitions, and `dct:source` references.
- All new concepts are members of `trsp:checklistCommunityEngagement`.

## Corrected
- Replaced erroneous `skos:inScheme trsp:typeBenefit` and `skos:inScheme trsp:typeResponsible` values with the actual checklist concept scheme.
- Added `skos:broader` links for existing subordinate concepts.
- Corrected the label and definition of `trsp:typeResponsible` (previously copied from Community Benefit).
- Removed the terminal period from the checklist preferred label; updated modification date and version.

## Sources and qualifications
- Principles of Open Scholarly Infrastructure: https://openscholarlyinfrastructure.org/
- TRUST Principles: https://doi.org/10.1038/s41597-020-0486-7
- CARE Principles: https://www.gida-global.org/care

`dct:source` denotes conceptual inspiration rather than exact quotation or normative equivalence. The new checklist considerations are proposed operational interpretations of these sources, not verbatim principle statements. Existing CARE `skos:relatedMatch` targets were preserved and have not been independently checked for dereferenceability.

## Validation
The resulting Turtle parses successfully with RDFLib (115 triples). No full SHACL validation was performed.
