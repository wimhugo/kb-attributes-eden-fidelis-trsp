# TRSP Batch 2 — re3data IRI revision

Revised the `r3d/` vocabulary identifiers to the `parent.child` form, preserving the original folder structure.

## Namespace decision

`@prefix r3d: <https://w3id.org/trsp/r3d/> .`

**Important:** This is a proposed namespace; its HTTP resolution depends on registering/configuring the corresponding w3id redirect. It is syntactically valid but not yet verified as dereferenceable.

## Results

- Turtle files checked: 12; all parse successfully.
- Distinct full-IRI replacements: 309.
- Existing source identifiers and replacements are recorded in `r3d/IRI-MAPPING.tsv`.
- Only files under `r3d/` were edited; other vocabulary directories and schema files are retained as supplied.

## Per-file changes

- `data_access-restriction.ttl`: updated; 3 distinct contextual `parent.child` identifiers.
- `data_access-type.ttl`: updated; 4 distinct contextual `parent.child` identifiers.
- `data_upload-restriction.ttl`: updated; 4 distinct contextual `parent.child` identifiers.
- `data_upload-type.ttl`: updated; 3 distinct contextual `parent.child` identifiers.
- `database_access-restriction.ttl`: updated; 2 distinct contextual `parent.child` identifiers.
- `database_access-type.ttl`: updated; 3 distinct contextual `parent.child` identifiers.
- `institution-type.ttl`: updated; 2 distinct contextual `parent.child` identifiers.
- `provider-type.ttl`: updated; 2 distinct contextual `parent.child` identifiers.
- `related_repository-type.ttl`: updated; 2 distinct contextual `parent.child` identifiers.
- `repository-type.ttl`: updated; 0 distinct contextual `parent.child` identifiers.
- `responsibility-type.ttl`: updated; 0 distinct contextual `parent.child` identifiers.
- `subject-type.ttl`: updated; 282 distinct contextual `parent.child` identifiers.

## Caveats

- A change of namespace changes RDF identity. Update external references to the previous IRIs using the mapping table.
- The old source-generated URLs were not treated as authoritative re3data term IRIs.
- SKOS semantic relations were preserved; this pass addresses identifiers, not concept definitions or ontology design.
- Cross-directory references should be checked during the final integrated audit.
