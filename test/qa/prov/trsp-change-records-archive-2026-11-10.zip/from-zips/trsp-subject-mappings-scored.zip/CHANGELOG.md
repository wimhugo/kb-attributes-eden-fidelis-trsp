# TRSP subject mapping — score-based candidate review

## Method

Scores are lexical similarities, not calibrated semantic probabilities. Score tiers are used for triage only. No new RDF mapping triples were asserted automatically; the 9 existing exact-label mappings are preserved.

| Score | Proposed relation | Candidate count |
|---|---|---:|
| >95 | `skos:exactMatch` | 0 |
| 80–95 | `skos:closeMatch` | 5 |
| 65–<80 | `skos:relatedMatch` | 45 |
| 50–<65 | `rdfs:seeAlso` | 115 |
| <50 | `no match` | 108 |

## High-score candidates requiring review

| re3data | FORD | Score | Score-based suggestion |
|---|---|---:|---|
| Prehistory and World Archaeology | History and archaeology | 83.6% | `skos:closeMatch` |
| Nutritional Sciences | Educational sciences | 80.0% | `skos:closeMatch` |
| Soil Sciences | Social sciences | 92.9% | `skos:closeMatch` |
| Veterinary Medical Science | Veterinary science | 81.8% | `skos:closeMatch` |
| Mechanical Process Engineering | Mechanical engineering | 84.6% | `skos:closeMatch` |

## Semantic safeguards

- `skos:exactMatch` is reserved for concepts with substantially equivalent meanings and scopes, not simply similar strings.
- `skos:closeMatch` requires strong semantic overlap.
- `skos:relatedMatch` is an associative mapping, not a generic similarity grade.
- `rdfs:seeAlso` is a general pointer, not a SKOS mapping relation.
- A narrower discipline should generally be evaluated for `skos:broadMatch` against a broader FORD subject, rather than forcing `closeMatch`.
- Existing nine `skos:exactMatch` statements were retained unchanged, although multiple hierarchical Mathematics concepts mapped to one FORD concept merit a separate semantic review.

## Validation

The Turtle file is unchanged from the previous mapped release. The score-based decisions are in `scored-candidates.tsv`; no questionable new semantic assertions were added.
