# TRSP vocabulary batch 1 — QA and change record

## Scope and approach

Reviewed nine vocabulary files from `trsp.zip` against the newly uploaded `trsp-core(1).ttl` and `trsp-shapes.ttl`. The authoritative core and shapes files are included unchanged, renamed `trsp-core.ttl` and `trsp-shapes.ttl`. Earlier revisions were not used.

All output Turtle files were parsed independently with RDFLib. Changes avoid renaming published concept IRIs or inventing definitions. External vocabulary mappings were not checked against live endpoints.

## File-level results

| File | Triples | Concepts | Missing label/definition checks |
|---|---:|---:|---:|
| `measurement-type.ttl` | 102 | 13 | 0 |
| `relation-type.ttl` | 23 | 2 | 0 |
| `identifier-usage.ttl` | 6 | 1 | 0 |
| `constraint-type.ttl` | 27 | 4 | 0 |
| `aggregation-type.ttl` | 119 | 18 | 0 |
| `imperative-type.ttl` | 57 | 5 | 0 |
| `cardinality-type.ttl` | 35 | 4 | 0 |
| `profile-type.ttl` | 95 | 7 | 0 |
| `service-relation-type.ttl` | 29 | 3 | 0 |

## Changes by file

### measurement-type.ttl

- Closed incomplete specification concept
- Corrected scheme title
- Corrected 15 xsd:dateTime datatype references
- Promoted 13 concept descriptions to skos:definition

### relation-type.ttl

- Removed misleading ProfileType typing from relation concepts
- Corrected concept scheme membership
- Corrected 4 xsd:dateTime datatype references
- Promoted 2 concept descriptions to skos:definition

### identifier-usage.ttl

- No semantic or syntax changes needed; normalized prefix declarations.

### constraint-type.ttl

- Corrected 2 xsd:dateTime datatype references

### aggregation-type.ttl

- Corrected 21 xsd:dateTime datatype references

### imperative-type.ttl

- No semantic or syntax changes needed; normalized prefix declarations.

### cardinality-type.ttl

- Corrected copied scheme description
- Corrected copied scheme title
- Repaired premature statement termination in scheme metadata
- Corrected 2 xsd:dateTime datatype references

### profile-type.ttl

- Corrected blank-node punctuation
- Corrected typo in TRSP prefix
- Aligned skos:inScheme with declared concept scheme
- Changed string literal to IRI for SKOS mapping
- Corrected spelling
- Corrected date literal datatype
- Corrected 1 xsd:dateTime datatype references

### service-relation-type.ttl

- Repaired premature statement termination in scheme metadata
- Corrected 5 xsd:dateTime datatype references

## Embedded class/property declarations

No explicit `owl:Class`, `rdfs:Class`, `rdf:Property`, `owl:ObjectProperty`, or `owl:DatatypeProperty` declarations found in the vocabulary batch; no schema declarations were moved to the core ontology.

## Issues requiring semantic review

- `trsp:MeasurementType`, `trsp:CardinalityType`, and related vocabulary-specific classes used as additional concept types should be compared with the authoritative core schema. No new class declarations were fabricated.
- The `profile-type.ttl` file contains potentially questionable `dct:source` references and SKOS mappings; verify these against the intended external concepts.
- Check whether `trsp:relationTypeAssertion` and `trsp:relationTypeAnnotation` should be instances of a dedicated `trsp:RelationType` class; this revision retains only `skos:Concept` typing.
- `xsd:dateTime` datatype case corrected; date-only values are expressed as `xsd:date` where identified.
- Prefixes were regenerated for each vocabulary; potentially redundant aliases such as `dct:` and `dcterms:` are preserved when actually used.
- This is Turtle parsing and structural QA, not full SHACL conformance testing of instance graphs.

## Validation

- Vocabulary files successfully parsed: **9 of 9**.
- Total vocabulary triples (sum by file): **493**.
- Embedded schema definitions requiring relocation: **0**.
