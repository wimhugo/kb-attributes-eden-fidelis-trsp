# TRSP research subject mappings — review

Input: `subject-type(1).ttl` (re3data) and `eosc-subject-type.ttl` (EOSC/FORD).

- Re3data concepts: 282; EOSC/FORD concepts: 48.
- Asserted `skos:exactMatch` mappings: 9.
- Remaining re3data concepts: 273 (candidate mappings provided for human review, **not asserted**).
- Mapping policy: normalized identical descriptive labels only, without ambiguous competing near-identical candidates. The r3d subject descriptions are in `skos:definition` rather than `skos:prefLabel`.
- Existing re3data IRIs and all other triples preserved. No inferred broader/narrower mappings added, since classification scope differs and requires expert review.
- Similarity scores in `review-candidates.tsv` are string-based only and do not establish semantic equivalence.
- The EOSC/FORD file is included unchanged for convenience.

## Asserted mappings

- `subjects.11` (Humanities) → `ford-6` (Humanities): `skos:exactMatch`
- `subjects.122` (Psychology) → `ford-5.1` (Psychology): `skos:exactMatch`
- `subjects.123` (Social Sciences) → `ford-5` (Social sciences): `skos:exactMatch`
- `subjects.12304` (Political Science) → `ford-5.6` (Political science): `skos:exactMatch`
- `subjects.3` (Natural Sciences) → `ford-1` (Natural sciences): `skos:exactMatch`
- `subjects.33` (Mathematics) → `ford-1.1` (Mathematics): `skos:exactMatch`
- `subjects.331` (Mathematics) → `ford-1.1` (Mathematics): `skos:exactMatch`
- `subjects.33101` (Mathematics) → `ford-1.1` (Mathematics): `skos:exactMatch`
- `subjects.431` (Materials Engineering) → `ford-2.5` (Materials engineering): `skos:exactMatch`
