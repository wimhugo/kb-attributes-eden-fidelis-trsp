# TRSP re3data → EOSC/FORD semantic mapping review

Reviewed the 165 candidates with lexical similarity >= 50%. The lexical candidate is **not** assumed to be the correct target; FORD disciplinary hierarchy and subject meaning determine the revised target and relation.

- Reviewed: 165
- New assertions: 133 ({'skos:closeMatch': 24, 'skos:broadMatch': 109})
- Not asserted or previously mapped: 32
- Existing exactMatch assertions preserved: 9 (not revalidated in this pass)
- Turtle parsed successfully: 2114 triples

`skos:broadMatch` indicates that the re3data subject is narrower than the referenced FORD category. `skos:closeMatch` indicates sufficiently comparable disciplinary scope, without claiming strict equivalence. No `skos:exactMatch` or `skos:relatedMatch` is created from lexical scores alone. `rdfs:seeAlso` is not used as a fallback similarity grade.

This is a **conservative expert-rule mapping pass**, not a validated ontology alignment. The crosswalk and pre-existing exactMatch assertions should be editorially reviewed, especially composite subjects and category boundaries. Unreviewed candidates scoring <50% may still have valid semantic matches.

The `semantic-review.tsv` records each candidate, its original lexical match, selected semantic target, asserted predicate and rationale. EOSC/FORD source remains unchanged.
