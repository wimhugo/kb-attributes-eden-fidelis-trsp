# TRSP attribute vocabularies — contextual definitions and prefix cleanup

Input: `attr(2).zip`. Source files were treated as authoritative. Original relative paths are retained.

- Turtle files processed: **40**
- Definitions added: **230**
- Prefix declarations removed: **29**
- Files with unresolved issues: **5**

Each inserted definition is marked `# definition added automatically`. Definitions are context-based editorial proposals, not verified authoritative definitions. No existing definitions or identifiers were intentionally changed.

| File | Missing definitions detected | Added | Unused prefixes removed |
|---|---:|---:|---|
| `aai-list-check.ttl` | 2 | 2 | — |
| `api-list-check.ttl` | 8 | 8 | rdfs |
| `businessmodel-type.ttl` | 0 | 0 | — |
| `community-check.ttl` | 3 | 3 | rdfs |
| `compensation-rule-type.ttl` | 5 | 0 | — |
| `contact-type.ttl` | 4 | 4 | rdfs |
| `curation-check.ttl` | 32 | 32 | rdfs |
| `data-protection-check.ttl` | 7 | 7 | — |
| `deposit-docs-check.ttl` | 5 | 5 | — |
| `ethics-check.ttl` | 2 | 2 | rdfs |
| `evidence-type.ttl` | 0 | 0 | rdfs,openrel,odrl,dcat,dqv |
| `governance-type.ttl` | 0 | 0 | — |
| `index-check.ttl` | 6 | 6 | rdfs |
| `info-management-check.ttl` | 5 | 5 | rdfs |
| `ingest-metadata-check.ttl` | 1 | 1 | rdfs |
| `institution-role-type.ttl` | 12 | 12 | rdfs |
| `instrument-type.ttl` | 0 | 0 | — |
| `legal-check.ttl` | 0 | 0 | — |
| `legislation-type.ttl` | 0 | 0 | — |
| `linkages-type.ttl` | 5 | 5 | rdfs |
| `metrics-check.ttl` | 6 | 6 | rdfs |
| `package-type.ttl` | 3 | 3 | — |
| `pid-resolution-type.ttl` | 3 | 3 | rdfs |
| `policies-check.ttl` | 1 | 1 | — |
| `policy-type.ttl` | 22 | 22 | rdfs |
| `principles-check.ttl` | 2 | 2 | — |
| `procedures-check.ttl` | 24 | 24 | — |
| `quality-assurance-check.ttl` | 18 | 18 | rdfs |
| `registry-check.ttl` | 6 | 6 | — |
| `repo-status-type.ttl` | 5 | 5 | rdfs |
| `resource-type.ttl` | 0 | 0 | rdf |
| `reuse-check.ttl` | 7 | 7 | — |
| `revenue-source-type.ttl` | 8 | 8 | — |
| `revenue-type.ttl` | 0 | 0 | — |
| `rights-encoding-type.ttl` | 0 | 0 | duo |
| `service-type.ttl` | 24 | 24 | rdfs |
| `trl-type.ttl` | 1 | 1 | rdf,rdfs,owl,xsd |
| `trsp-core.ttl` | 0 | 0 | — |
| `user-schema-check.ttl` | 4 | 4 | rdfs |
| `versioning-strategy-type.ttl` | 4 | 4 | rdfs |

## Unresolved issues
- `businessmodel-type.ttl` (output): Lost 14 original triples
- `compensation-rule-type.ttl` (output): Lost 3 original triples
- `legislation-type.ttl` (output): Lost 3 original triples
- `revenue-type.ttl` (output): Lost 3 original triples
- `trsp-core.ttl` (output): Lost 82 original triples

## Validation
Each modified Turtle file was parsed using RDFLib; original RDF triples were checked for preservation.
