# TRSP change-record archive

Created 2026-11-10 from Markdown and CSV files currently accessible in the working directory, including copies embedded in ZIP outputs.

- `loose/`: standalone records, preserving relative paths.
- `from-zips/`: records extracted from earlier ZIP deliverables, preserving their original ZIP name and internal path.
- `manifest.csv`: provenance-oriented listing with SHA-256 digests and original source paths.

This is an archive of **available files**, not a guarantee that every record ever mentioned in the conversation is present. Some records appear in both loose and ZIP forms. No standalone CSV migration register has been supplied yet.
