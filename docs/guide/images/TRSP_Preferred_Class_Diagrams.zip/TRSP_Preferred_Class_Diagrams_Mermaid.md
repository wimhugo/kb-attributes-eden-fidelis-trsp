# TRSP class diagrams — repository markup

## Summary

```mermaid
classDiagram
  Repository ..> Profile : hasProfile*
  Service ..> Profile : hasProfile*
  Service <|-- APIService
  Profile <|-- RepositoryProfile
  Profile <|-- ServiceProfile
  Profile <|-- SourceProfile
  Profile <|-- StandardProfile
  Profile <|-- CommunityProfile
  Profile --> ProfileProperty : hasProperty
  ProfileProperty --> Attribute : hasAttribute
  ProfileProperty ..> Constraint : hasConstraint*
  Attribute ..> Constraint : hasConstraint*
  Evidence <|-- ChecklistItem
  Checklist --> ChecklistItem : checkItem
  ProfileMapping --> Profile : sourceProfile / targetProfile
  ProfileMapping ..> PropertyMapping : hasPropertyMapping*
  ProfileMapping --> ClassMapping : hasClassMapping
  PropertyMapping --> ProfileProperty : source / target
  PropertyMapping --> Attribute : mappedAttribute
  PropertyMapping ..> ValueMapping : hasValueMapping*
  PropertyMapping ..> MappingQualifier : hasQualifier*
  ClassMapping ..> MappingQualifier : hasQualifier*
```

`*` indicates an intended reusable relationship whose `rdfs:domain` is deliberately omitted.
